"""
Author: Steve Paul 
Date: 7/28/22 """
import pickle

import torch
import os


num_samples = 3

max_n_agent = 10
robot_sizes = [2,3,5,7]
mult_factors = [.5,1,2,4,10, 20]

for mult in mult_factors:
    n_tasks = int(mult * 100)
    if not os.path.isdir(str(n_tasks)):
        os.makedirs(str(n_tasks))

    for robot_size in robot_sizes:
        n_robots = robot_size


        n_agents_available = n_robots#torch.tensor([2, 3, 5, 7])
        size = n_tasks
        agents_ids = torch.randint(0, 4, (num_samples, 1))

        # groups = torch.randint(1, 3, (num_samples, 1))
        for groups in range(1,3):

            # dist = torch.randint(1, 5, (num_samples, 1))
            for dist in range(1,5):
                max_speed=0.01
                data = []

                for i in range(num_samples):
                    n_agents = n_robots#n_agents_available[agents_ids[i, 0].item()].item()
                    agents_location = (torch.randint(0, 101, (n_agents, 2)).to(torch.float) / 100)

                    loc = torch.FloatTensor(size, 2).uniform_(0, 1)
                    workload = torch.FloatTensor(size).uniform_(.2, .2)
                    d_low = (((loc[:, None, :].expand((size, n_agents, 2)) - agents_location[None].expand(
                        (size, n_agents, 2))).norm(2, -1).max() / max_speed) + 20).to(torch.int64) + 1
                    d_high = ((35) * (45) * 100 / (380) + d_low).to(torch.int64) + 1
                    d_low = d_low * (.5 * groups)
                    d_high = ((d_high * (.5 * groups) / 10).to(torch.int64) + 1) * 10
                    deadline_normal = (torch.rand(size, 1) * (d_high - d_low) + d_low).to(torch.int64) + 1

                    n_norm_tasks = dist * int(.25*n_tasks)
                    rand_mat = torch.rand(size, 1)
                    k = n_norm_tasks # For the general case change 0.25 to the percentage you need
                    k_th_quant = torch.topk(rand_mat.T, k, largest=False)[0][:, -1:]
                    bool_tensor = rand_mat <= k_th_quant
                    normal_dist_tasks = torch.where(bool_tensor, torch.tensor(1), torch.tensor(0))

                    slack_tasks = (normal_dist_tasks - 1).to(torch.bool).to(torch.int64)

                    normal_dist_tasks_deadline = normal_dist_tasks * deadline_normal

                    slack_tasks_deadline = slack_tasks * d_high

                    deadline_final = normal_dist_tasks_deadline + slack_tasks_deadline

                    robots_start_location = (torch.randint(0, 101, (n_agents, 2)).to(torch.float) / 100).to(
                        device=deadline_final.device)

                    robots_work_capacity = torch.randint(1, 3, (n_agents, 1), dtype=torch.float,
                                                         device=deadline_final.device).view(-1) / 100

                    case_info = {
                        'loc': loc.numpy(),
                        # 'depot': torch.FloatTensor(1, 2).uniform_(0, 1),
                        'deadline': deadline_final.to(torch.float).view(-1).numpy(),
                        'workload': workload.numpy(),
                        # 'initial_size': 100,
                        'n_agents': torch.tensor([[n_agents]]).numpy(),
                        # 'max_n_agents': torch.tensor([[max_n_agent]]),
                        'max_speed': max_speed,
                        'robots_start_location': robots_start_location.numpy(),
                        'robots_work_capacity': robots_work_capacity.numpy()
                    }

                    data.append(case_info)

                output_file = str(n_tasks)+"_"+str(n_robots)+"_"+str(groups)+"_"+str(dist)+".pkl"
                with open(str(n_tasks)+"/"+output_file, 'wb') as fl:
                    pickle.dump(data, fl)
